"""mdnotes - CLI tool for managing and searching Markdown notes."""

__version__ = "0.1.0"

# Core modules will be added by agents as they build features
# Example future imports:
# from .indexer import Indexer
# from .searcher import Searcher
# from .graph import GraphGenerator
